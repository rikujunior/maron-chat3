1) index.html の GAS_URL にあなたのGASウェブアプリURLを貼る。
2) index.html / manifest.webmanifest / maron-chat3-icon.png / maron-chat3-icon-180.png を同じ場所にアップロード。
3) GitHub Pagesなどで公開。
4) iPadのSafariで公開URLを開き、共有→ホーム画面に追加。
